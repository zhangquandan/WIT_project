const API = {
    "baseUrl": "http://47.110.33.227:8180",

    "login": "/wsis-sso/user/login?username=admin&password=whbs20200827",
    "area": "/wsis/api/waterregion/LeakageIndex",
    "meterInfo": "/wsis/api/watermeter/search",
    "CustomTimeDay": "wsis/api/waterregion/Quantity/CustomTimeDay",
    "CustomTimeMonth": "wsis/api/waterregion/Quantity/CustomTimeMonth",
    "CustomTimeYear": "wsis/api/waterregion/Quantity/Years",
    "getColor": "wsis/api/legendStatisticsStandard",
    "waterregionWaterquotaList": "/wsis/api/waterregionWaterquotaList",
    "getMwater": "/wsis/api/waterregion/Quantity/YearMonth?pageNum=1&pageSize=100",
    "getSchoolInfo": "/wsis/api/statsvariable",
    "waterMeter": "/wsis/api/logWatermeter/LeakageIndex",
    "bulid": "/wsis/api/building/LeakageIndex",

    "HomeUrl": "http://47.110.33.227:8180/wit/#/WaterPublicity/WaterSurvey"
}